using Domain.Entities;
using Domain.Interfaces;
using Infrastructure.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors();
builder.Services.AddHttpClient();
builder.Services.AddSingleton<IRepositorioService, RepositorioService>();

builder.Services.AddHttpClient<IRepositorioService, RepositorioService>(client =>
{
    client.DefaultRequestHeaders.UserAgent.ParseAdd("MyApp"); // GitHub exige User-Agent
});

var app = builder.Build();

app.Use(async (context, next) =>
{
    try
    {
        await next();
    }
    catch (Exception ex)
    {
        var logger = context.RequestServices.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex, "Erro não tratado");

        context.Response.StatusCode = 500;
        await context.Response.WriteAsJsonAsync(new { error = "Erro interno no servidor." });
    }
});
app.UseSwagger();
app.UseSwaggerUI();
app.UseCors(p => p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());

app.MapGet("/repos/relevantes", async (string nome, IRepositorioService service) =>
{
    var repos = await service.ListarRepositoriosDoUsuario(nome);
    var ordenados = repos
        .OrderByDescending(r => r.Relevancia)
        .ToList();

    return Results.Ok(ordenados);
});

app.MapPost("/favoritos", async (Favorito favorito, IRepositorioService service) =>
{
    await service.AdicionarFavorito(favorito);
    return Results.Ok(new { message = "Favorito adicionado." });
});

app.MapGet("/favoritos", async (IRepositorioService service) =>
{
    var favoritos = await service.ListarFavoritos();
    return Results.Ok(favoritos);
});

app.Run();
